<?php

//Site
$siteURL = "http://localhost/olx";
$siteName = "olx";

//DB 
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'olx';

//General Settings 
$defaultLan = 'en';
$defaultThemeColor = 'blue';


?>